<!-- core:js -->
	<script src="<?php echo e(asset('admin/assets/vendors/core/core.js')); ?>"></script>
	<!-- endinject -->

	<!-- Plugin js for this page -->
  <script src="<?php echo e(asset('admin/assets/vendors/flatpickr/flatpickr.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/assets/vendors/apexcharts/apexcharts.min.js')); ?>"></script>
	<!-- End plugin js for this page -->

	<!-- inject:js -->
	<script src="<?php echo e(asset('admin/assets/vendors/feather-icons/feather.min.js')); ?>"></script>
	<script src="<?php echo e(asset('admin/assets/js/template.js')); ?>"></script>
	<!-- endinject -->

	<!-- Custom js for this page -->
  <script src="<?php echo e(asset('admin/assets/js/dashboard-dark.js')); ?>"></script>
	<!-- End custom js for this page --><?php /**PATH D:\WWW\monoj\molla-e-commerce-project\resources\views/admin/master/js.blade.php ENDPATH**/ ?>